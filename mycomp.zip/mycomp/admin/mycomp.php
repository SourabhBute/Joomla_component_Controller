<?php 

defined('_JEXEC')or die("access deny");

echo "<h3>Welcome to Mycom Backend</h3>";

?>