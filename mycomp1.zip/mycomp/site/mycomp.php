<?php


defined('_JEXEC') or die("Acess deny");

// echo "<h3>Welcome to front end</h3>";


// get instance
$controller=JControllerLegacy::getInstance('MyComp');

//perform the task 

$input = JFactory::getApplication()->input;

$controller->execute($input->getCmd('task'));


$controller->redirect();










 ?>