<?php 
defined('_JEXEC') or die("Access Deny");

class MyCompController extends JControllerlegacy

{            

      function display($cachable = false, $urlparams = false){

      	echo "I am Without task";
      }


       function create(){

       	echo "welcome to create";
       }


      function delete(){

      	 $app=JFactory::getApplication();

          $id=JRequest::getVar('id');
          
          echo "you want to delete $id";

          $app->close();


      }

       function  edit()
        {
           echo "Edit Function called";

        }



}





?>