<?php 
defined('_JEXEC') or die("Access Deny");

/**
 * 
 */
class MyCompController extends JControllerLegacy
{
	function display($cachable = false, $urlparams = array()){

		echo JText::_("COM_MYCOMP_WELCOME_MESSAGE");
	}
	function create()
	{
		echo JText::_("COM_MYCOMP_CREATE_TASK");
	}

	function delete()
	{

      echo JText::_("COM_MYCOMP_DELTE_TASK");
	}
}



?>